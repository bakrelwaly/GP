-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2019 at 12:57 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gp_62`
--

-- --------------------------------------------------------

--
-- Table structure for table `attends`
--

CREATE TABLE `attends` (
  `id` int(10) UNSIGNED NOT NULL,
  `teacher_id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `attend` tinyint(1) NOT NULL,
  `max_grade` int(11) NOT NULL,
  `grade` int(11) NOT NULL,
  `date` varchar(10) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `available_times`
--

CREATE TABLE `available_times` (
  `id` int(10) UNSIGNED NOT NULL,
  `teacher_id` int(10) UNSIGNED NOT NULL,
  `day` varchar(10) NOT NULL,
  `from_time` varchar(10) NOT NULL,
  `to_time` varchar(10) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `centers`
--

CREATE TABLE `centers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `centers`
--

INSERT INTO `centers` (`id`, `name`, `active`, `created_at`, `updated_at`) VALUES
(1, 'العبودي', 0, NULL, NULL),
(2, 'الصفوه', 0, NULL, NULL),
(3, 'الياسمين', 0, NULL, NULL),
(5, 'o', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `days`
--

CREATE TABLE `days` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `nearDay` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `days`
--

INSERT INTO `days` (`id`, `name`, `nearDay`) VALUES
(1, 'السبت', 1),
(2, 'الاحد', 1),
(3, 'الأثنين', 1),
(4, 'الثلاثاء', 1),
(5, 'الأربعاء', 1),
(6, 'الخميس', 1),
(7, 'الجمعه', 1);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`) VALUES
(5, '0'),
(1, 'ادبي'),
(2, 'علمي '),
(3, 'علمي رياضه'),
(4, 'علمي علوم');

-- --------------------------------------------------------

--
-- Table structure for table `levels`
--

CREATE TABLE `levels` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `stage` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `levels`
--

INSERT INTO `levels` (`id`, `name`, `stage`) VALUES
(1, 'الصف الاول الاعدادي', '1'),
(2, 'الصف الثاني الاعدادي', '1'),
(3, 'الصف الثالث الاعدادي', '1'),
(4, 'الصف الاول الثانوى', '2'),
(5, 'الصف الثاني الثانوى', '2'),
(6, 'الصف الثالث الثانوى', '2'),
(10, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_10_100001_create_type_users_table', 1),
(2, '2014_10_10_100002_create_levels_table', 1),
(3, '2014_10_10_100003_create_subjects_table', 1),
(4, '2014_10_10_100004_create_times_table', 1),
(5, '2014_10_10_100005_create_days_table', 1),
(6, '2014_10_10_100006_create_departments_table', 1),
(7, '2014_10_10_100007_create_schools_table', 1),
(8, '2014_10_10_100008_create_centers_table', 1),
(9, '2014_10_10_111753_create_rooms_table', 1),
(10, '2014_10_11_000000_create_users_table', 1),
(11, '2014_10_11_100000_create_password_resets_table', 1),
(12, '2014_10_12_110847_create_available_times_table', 1),
(13, '2018_02_04_152016_create_sessions_table', 1),
(14, '2018_02_04_152548_create_tc_sessions_table', 1),
(15, '2018_02_04_171052_create_students_tc_sessions_relationships_table', 1),
(16, '2018_02_04_183427_create_attends_table', 1),
(17, '2016_06_01_000001_create_oauth_auth_codes_table', 2),
(18, '2016_06_01_000002_create_oauth_access_tokens_table', 2),
(19, '2016_06_01_000003_create_oauth_refresh_tokens_table', 2),
(20, '2016_06_01_000004_create_oauth_clients_table', 2),
(21, '2016_06_01_000005_create_oauth_personal_access_clients_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(3, NULL, 'Laravel Personal Access Client', 'cVdhk4o17d0hfgVUPr5jYI1ZrJPwwrRgoLCuiR5F', 'http://localhost', 1, 0, 0, '2019-03-01 08:00:34', '2019-03-01 08:00:34'),
(4, NULL, 'Laravel Password Grant Client', 'jD4mer4XnxeFP3t2Mhc1i2AJwV7chsl6yVTm7Wpd', 'http://localhost', 0, 1, 0, '2019-03-01 08:00:34', '2019-03-01 08:00:34');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(2, 3, '2019-03-01 08:00:34', '2019-03-01 08:00:34');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(10) UNSIGNED NOT NULL,
  `max` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`id`, `name`, `active`, `created_at`, `updated_at`) VALUES
(1, 'خليل اغا', 0, NULL, NULL),
(2, 'اسماعيل القباني', 0, NULL, NULL),
(3, 'النصر التجربيه', 0, NULL, NULL),
(4, 'عمر ابن الخطاب', 0, NULL, NULL),
(6, '0', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `students_tc_sessions_relationships`
--

CREATE TABLE `students_tc_sessions_relationships` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `teacher_id` int(10) UNSIGNED NOT NULL,
  `session_id` int(10) UNSIGNED NOT NULL,
  `approve` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `near` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `near`) VALUES
(1, 'الدرسات الأجتماعيه', '1'),
(2, 'اللغه العربيه', '1'),
(3, 'اللغه الأنجليزيه', '1'),
(4, 'العلوم', '1'),
(5, 'الحساب', '1'),
(7, 'الفزياء ', '1'),
(8, 'الكمياء', '1'),
(9, 'الاحياء', '1'),
(10, 'التربيه الدينيه', '1'),
(11, 'الكمبيوتر', '1'),
(12, 'الاحصاء', '1'),
(13, 'رياضه تطبيقيه', '1'),
(14, 'رياضه بحته', '1'),
(15, 'التاريخ', '1'),
(16, 'الجغرافيه', '1'),
(18, 'كمياء', '1'),
(19, 'Math', '2'),
(39, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tc_sessions`
--

CREATE TABLE `tc_sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `center` varchar(255) NOT NULL,
  `teacher_id` int(10) UNSIGNED NOT NULL,
  `level` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `price` int(11) NOT NULL DEFAULT '35',
  `day` varchar(255) NOT NULL,
  `start` varchar(255) NOT NULL,
  `end` varchar(255) NOT NULL,
  `visibleCenter` tinyint(1) NOT NULL DEFAULT '1',
  `visibleTeacher` tinyint(1) NOT NULL DEFAULT '1',
  `approve` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `times`
--

CREATE TABLE `times` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `nearTime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `times`
--

INSERT INTO `times` (`id`, `name`, `nearTime`) VALUES
(2, '09:00 AM', 1),
(3, ' 09:30 AM', 1),
(4, ' 10:00 AM', 1),
(5, '10:30 AM', 1),
(6, '11:00 AM', 1),
(7, ' 11:30 AM', 1),
(8, '12:00 BM', 1),
(9, ' 12:30 BM', 1),
(10, '01:00 BM', 1),
(11, '01:30 BM', 1),
(12, '02:00 BM', 1),
(13, '02:30 BM', 1),
(14, '03:00 BM', 1),
(15, '03:30 BM', 1),
(17, '04:00 BM', 1),
(18, '04:30 BM', 1),
(19, '05:00 BM', 1),
(20, '05:30 BM', 1),
(21, '06:00 BM', 1),
(22, '06:30 BM', 1),
(23, '07:00 BM', 1),
(24, '07:30 BM', 1),
(25, '08:00 BM', 1),
(26, '08:30 BM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `type_users`
--

CREATE TABLE `type_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type_users`
--

INSERT INTO `type_users` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Student', NULL, NULL),
(2, 'Parent', NULL, NULL),
(3, 'Teacher', NULL, NULL),
(4, 'Center Manger', NULL, NULL),
(7, '0', NULL, NULL),
(9, 'Admin', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `typeUserID` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `type` varchar(255) NOT NULL DEFAULT 'user',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '0',
  `department` varchar(255) NOT NULL DEFAULT '0',
  `school` varchar(255) NOT NULL DEFAULT '0',
  `phone_1` int(11) NOT NULL DEFAULT '0',
  `phone_2` int(11) NOT NULL DEFAULT '0',
  `photo` varchar(255) NOT NULL DEFAULT '0',
  `gender` varchar(255) NOT NULL DEFAULT '0',
  `RegStatus` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `typeUserID`, `type`, `name`, `email`, `password`, `level`, `subject`, `department`, `school`, `phone_1`, `phone_2`, `photo`, `gender`, `RegStatus`, `remember_token`, `created_at`, `updated_at`) VALUES
(16, 1, 'admin', 'mohamed1', 'mohamed1@gmail.com', '$2y$10$.ESF0EKU9b.l2SD0QMPC7eXIWCCHLsY9dw.mVD8rfodU32KEVmaqu', '0', '0', '0', '0', 0, 0, '0', '0', 1, 'H0QGe9QWunc2XdyZY2zQXl7QyNgtYmN4EVjNhwUGy5EnuvL8Rd4uzaw8teo5', '2019-02-28 16:29:02', '2019-02-28 16:29:02'),
(17, 1, 'user', 'mohamed2', 'mohamed2@gmail.com', '$2y$10$cv/uIVHkIcCBI3zOqQ.tY.9W2.4Q..8tkOMRWOGH52eM8PsTg86ja', '0', '0', '0', '0', 0, 0, '0', '0', 1, 'XpJMUPqhEIzBHH0P4AVMwURpR3dDSdO1xUUKlsQoPhFHSLXzPvRT7OBeIzy7', '2019-03-01 08:10:04', '2019-03-01 08:10:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attends`
--
ALTER TABLE `attends`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attends_teacher_id_foreign` (`teacher_id`),
  ADD KEY `attends_student_id_foreign` (`student_id`),
  ADD KEY `attends_session_id_foreign` (`session_id`);

--
-- Indexes for table `available_times`
--
ALTER TABLE `available_times`
  ADD PRIMARY KEY (`id`),
  ADD KEY `available_times_teacher_id_foreign` (`teacher_id`);

--
-- Indexes for table `centers`
--
ALTER TABLE `centers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `centers_name_unique` (`name`);

--
-- Indexes for table `days`
--
ALTER TABLE `days`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `days_name_unique` (`name`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `departments_name_unique` (`name`);

--
-- Indexes for table `levels`
--
ALTER TABLE `levels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `levels_name_unique` (`name`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `schools_name_unique` (`name`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `students_tc_sessions_relationships`
--
ALTER TABLE `students_tc_sessions_relationships`
  ADD PRIMARY KEY (`id`),
  ADD KEY `students_tc_sessions_relationships_student_id_foreign` (`student_id`),
  ADD KEY `students_tc_sessions_relationships_teacher_id_foreign` (`teacher_id`),
  ADD KEY `students_tc_sessions_relationships_session_id_foreign` (`session_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subjects_name_unique` (`name`);

--
-- Indexes for table `tc_sessions`
--
ALTER TABLE `tc_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tc_sessions_center_foreign` (`center`),
  ADD KEY `tc_sessions_teacher_id_foreign` (`teacher_id`),
  ADD KEY `tc_sessions_level_foreign` (`level`),
  ADD KEY `tc_sessions_subject_foreign` (`subject`),
  ADD KEY `tc_sessions_day_foreign` (`day`),
  ADD KEY `tc_sessions_start_foreign` (`start`),
  ADD KEY `tc_sessions_end_foreign` (`end`);

--
-- Indexes for table `times`
--
ALTER TABLE `times`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `times_name_unique` (`name`);

--
-- Indexes for table `type_users`
--
ALTER TABLE `type_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_typeuserid_foreign` (`typeUserID`),
  ADD KEY `users_level_foreign` (`level`),
  ADD KEY `users_subject_foreign` (`subject`),
  ADD KEY `users_department_foreign` (`department`),
  ADD KEY `users_school_foreign` (`school`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attends`
--
ALTER TABLE `attends`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `available_times`
--
ALTER TABLE `available_times`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `centers`
--
ALTER TABLE `centers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `days`
--
ALTER TABLE `days`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `levels`
--
ALTER TABLE `levels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `students_tc_sessions_relationships`
--
ALTER TABLE `students_tc_sessions_relationships`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `tc_sessions`
--
ALTER TABLE `tc_sessions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `times`
--
ALTER TABLE `times`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `type_users`
--
ALTER TABLE `type_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `attends`
--
ALTER TABLE `attends`
  ADD CONSTRAINT `attends_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `tc_sessions` (`id`),
  ADD CONSTRAINT `attends_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `attends_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `available_times`
--
ALTER TABLE `available_times`
  ADD CONSTRAINT `available_times_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `students_tc_sessions_relationships`
--
ALTER TABLE `students_tc_sessions_relationships`
  ADD CONSTRAINT `students_tc_sessions_relationships_session_id_foreign` FOREIGN KEY (`session_id`) REFERENCES `tc_sessions` (`id`),
  ADD CONSTRAINT `students_tc_sessions_relationships_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `students_tc_sessions_relationships_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `tc_sessions`
--
ALTER TABLE `tc_sessions`
  ADD CONSTRAINT `tc_sessions_center_foreign` FOREIGN KEY (`center`) REFERENCES `centers` (`name`),
  ADD CONSTRAINT `tc_sessions_day_foreign` FOREIGN KEY (`day`) REFERENCES `days` (`name`),
  ADD CONSTRAINT `tc_sessions_end_foreign` FOREIGN KEY (`end`) REFERENCES `times` (`name`),
  ADD CONSTRAINT `tc_sessions_level_foreign` FOREIGN KEY (`level`) REFERENCES `levels` (`name`),
  ADD CONSTRAINT `tc_sessions_start_foreign` FOREIGN KEY (`start`) REFERENCES `times` (`name`),
  ADD CONSTRAINT `tc_sessions_subject_foreign` FOREIGN KEY (`subject`) REFERENCES `subjects` (`name`),
  ADD CONSTRAINT `tc_sessions_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_department_foreign` FOREIGN KEY (`department`) REFERENCES `departments` (`name`),
  ADD CONSTRAINT `users_level_foreign` FOREIGN KEY (`level`) REFERENCES `levels` (`name`),
  ADD CONSTRAINT `users_school_foreign` FOREIGN KEY (`school`) REFERENCES `schools` (`name`),
  ADD CONSTRAINT `users_subject_foreign` FOREIGN KEY (`subject`) REFERENCES `subjects` (`name`),
  ADD CONSTRAINT `users_typeuserid_foreign` FOREIGN KEY (`typeUserID`) REFERENCES `type_users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
